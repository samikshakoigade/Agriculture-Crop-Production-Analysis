India's Agricultural Crop Production Analysis (1997-2021)

HOW TO RUN
1. Extract the complete BookLanding_Agriculture_Project.zip folder.
2. Open the extracted BookLanding folder in Visual Studio Code.
3. Install the Live Server extension if it is not already installed.
4. Right-click index.html and select "Open with Live Server".

IMPORTANT
- Keep the assets folder in the same BookLanding folder as index.html.
- Do not move index.html outside the project folder.
- The Tableau dashboard requires an internet connection.
- The "View Full Dashboard" button opens the Tableau Public story in a new tab.
